James Malcolm (malcolm@gatech.edu)
www.ece.gatech.edu/~malcolm

Matlab wrapper for graph cut image segmentation.

Works on 32bit Linux and Mac OSX.

To run:
   >> run


To compile:
   bash$ cd src
   bash$ make
     ...or from within Matlab:
   >> cd src
   >> compile
