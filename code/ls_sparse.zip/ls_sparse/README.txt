James Malcolm (malcolm@bwh.harvard.edu)
www.jgmalcolm.com

From paper:
    @Article{Whitaker1998,
      author = {R. Whitaker},
      title = {A level-set approach to {3D} reconstruction from range data},
      journal = {Int. J. of Computer Vision},
      volume = 29,
      number = 3,
      year = 1998
    }

For 2D demo, run from inside Matlab:
  >> run
Select rectangular region (left click top left, drag and release at bottom
right)


For 3D demo, run from inside Matlab:
  >> run3
