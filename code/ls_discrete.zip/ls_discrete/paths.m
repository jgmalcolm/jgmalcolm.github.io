function paths
  if ~exist('mask2phi'), addpath('./util'); end
  if ~exist('mean_speed'), addpath('./speeds'); end
end
