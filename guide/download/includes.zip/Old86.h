; ACZ include file: TI-85 equates
; Assembly Coder's Zenith - http://www.acz.org/
; version: January 30, 1999

MUL_HL		 		equ 	4547h		; _HtimesL
CP_HL_DE 			equ 	403Ch		; _cphlde
LD_HL_MHL 			equ 	4010h		; _ldhlind
GET_KEY 			equ 	4068h		; _get_key
UNPACK_HL 			equ 	4044h		; _divHLby10
D_HL_DECI 			equ 	4A33h		; _dispAHL

CONTRAST			equ		0C008h		; _contrast
TEXT_MEM			equ		0C0F9h		; _textShadow
GRAPH_MEM			equ		0C9FAh		; _plotSScreen
TEXT_MEM2			equ		0CFABh		; _cmdShadow
VAT_END				equ		0D298h
VIDEO_MEM			equ		0FC00h

.end

 This file is included for compatibility with asm source
 code that use old TI-85 equates, please don't use them
 anymore :)
___________________________________________________________
(C)1999 ACZ - Assembly Coder's Zenith - http://www.acz.org/