
int Encode(unsigned char * InData,int length,unsigned char typebyte, FILE * OutFile);
void Decode(unsigned char * OutData,FILE * InFile);


