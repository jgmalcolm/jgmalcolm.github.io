/**************************************************************
	LZSS.C -- A Data Compression Program

        adapted for use with the TI-86 implementation
        of LZSS, 'BLOAT' by Matthew Shepcar  15/03/98

***************************************************************
	4/6/1989 Haruhiko Okumura
	Use, distribute, and modify this program freely.
	Please send me your improved versions.
		PC-VAN		SCIENCE
		NIFTY-Serve	PAF01022
		CompuServe	74050,1022
**************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define N                  32768        // max buffer size
#define F                     36        // max match length
#define THRESHOLD              2
#define NIL                   -1       

int databits,lenbits,posbits,buflen,maxmatchlen;
long textsize,codesize,todo;
unsigned char text_buf[N + F - 1],*outdata;         
int match_position,match_length,lson[N+1],rson[N+257],dad[N+1];
FILE *infile,*outfile;  
unsigned char mask,bitbuf;

void InitTree(void)  
{
	int  i;                         
        for(i=buflen+1;i<=buflen+256;i++) rson[i]=NIL;
        for(i=0;i<buflen;i++) dad[i]=NIL;
}

void InsertNode(int r)
{
        int i,p,cmp;
        unsigned char *key;

        cmp=1; key=&text_buf[r]; p=buflen+1+key[0];
        rson[r]=lson[r]=NIL; match_length=0;
        for(;;) {
                if (cmp>=0) {
                        if (rson[p]!=NIL) p=rson[p];
                        else {rson[p]=r; dad[r]=p; return;}
		} else {
                        if (lson[p]!=NIL) p=lson[p];
                        else {lson[p]=r; dad[r]=p; return;}
		}
                for(i=1;i<maxmatchlen;i++)
                        if ((cmp=key[i]-text_buf[p + i])!=0) break;
                if (i>match_length) {
                        match_position=p;
                        if ((match_length=i)>=maxmatchlen) break;
		}
        }
        dad[r]=dad[p]; lson[r]=lson[p]; rson[r]=rson[p];
        dad[lson[p]]=r; dad[rson[p]]=r;
        if (rson[dad[p]]==p) rson[dad[p]]=r;
        else lson[dad[p]]=r;
        dad[p]=NIL; 
}

void DeleteNode(int p)
{
        int q;
	
        if (dad[p]==NIL) return; 
        if (rson[p]==NIL) q=lson[p];
        else if (lson[p]==NIL) q=rson[p];
	else {
                q=lson[p];
                if (rson[q]!=NIL) {
                        do {q=rson[q];} while (rson[q]!=NIL);
                        rson[dad[q]]=lson[q]; dad[lson[q]]=dad[q];
                        lson[q]=lson[p]; dad[lson[p]]=q;
		}
                rson[q]=rson[p]; dad[rson[p]]=q;
	}
        dad[q]=dad[p];
        if (rson[dad[p]]==p) rson[dad[p]]=q; else lson[dad[p]]=q;
        dad[p]=NIL;
}

void putbit(int value)
{
        if (value) bitbuf|=mask;
        if (!(mask<<=1))
        {
                putc(bitbuf,outfile);
                mask=1;
                codesize++;
                bitbuf=0;
        }
}

int getbit(void)
{
        int c;
        if (!mask)
        {
                mask=1;
                if ((todo--)>0)
                        bitbuf=getc(infile);
        }
        if (todo<0) return -1;
        c=(bitbuf & mask) ? 1 : 0;
        mask<<=1;
        return c;
}

int getbits(int n)
{
        int v,i,c;
        for(i=0,v=0;i<n;i++)
        {
                if ((c=getbit())<0) return -1;
                v=(v<<1)+c;
        }
        return v;
}

void putbits(int num,int value)
{
        int x;       
        for(x=(1<<(num-1));x;x>>=1)
                putbit(value & x);
}

int Encode(unsigned char * InData,int length,unsigned char typebyte,FILE * OutFile)
{
        int i,c,len,r,s,last_match_length,start;

        databits=(typebyte & 7)+1;
        lenbits=((typebyte>>3) & 3)+2;
        posbits=((typebyte>>5) & 7)+8;
        buflen=(1<<posbits);
        maxmatchlen=((1<<lenbits)+THRESHOLD+1);

        todo=length; outfile=OutFile;
        textsize=codesize=0;
        start=ftell(outfile);
        fseek(outfile,2,1);
        putc(typebyte,outfile);
	
        InitTree();
        mask=1; bitbuf=0;
        s=0;  r=buflen-maxmatchlen;
        for(len=0;len<maxmatchlen && todo>0;len++,todo--)
                text_buf[r+len]=*InData++;
        if ((textsize=len)==0) return -1;
        InsertNode(r); 
	do {
                if (match_length>len) match_length=len;
                if (match_length<=THRESHOLD) {
                        match_length=1;
                        putbit(1);
                        putbits(databits,text_buf[r]);
		} else {
                        putbit(0);
                        putbits(posbits,match_position-r);
                        putbits(lenbits,match_length-(THRESHOLD+1));
		}
                last_match_length=match_length;
                for(i=0;i<last_match_length && todo>0;i++,todo--) {
                        DeleteNode(s);
                        text_buf[s]=*InData++;
                        if (s<maxmatchlen-1) text_buf[s+buflen]=c; 
                        s=(s+1) & (buflen-1); r=(r+1) & (buflen-1);
                        InsertNode(r);
		}
                while (i++<last_match_length) {
                        DeleteNode(s);         
                        s=(s+1) & (N-1); r=(r+1) & (buflen-1);
                        if (--len) InsertNode(r);
		}
        } while (len>0);
        putc(bitbuf,outfile);
        codesize+=2;
        fseek(outfile,start,0);
        fwrite(&codesize,2,1,outfile);
        fseek(outfile,0,2);
        return codesize;
}


void Decode(unsigned char * OutData,FILE * InFile) 
{
        int i,j,k,r,c;
        unsigned char typebyte;

        infile=InFile;
        mask=0;
        fread(&todo,2,1,InFile);
        fread(&typebyte,1,1,InFile);

        databits=(typebyte & 7)+1;
        lenbits=((typebyte>>3) & 3)+2;
        posbits=((typebyte>>5) & 7)+8;
        buflen=(1<<posbits);
        maxmatchlen=((1<<lenbits)+THRESHOLD+1);

        r=buflen-maxmatchlen;  
        for(;;) {
                if ((c=getbit())<0) return;
                if (c) {
                        c=getbits(databits);
                        if (c<0) return;
                        *OutData++=text_buf[r++]=c;
                        r&=(buflen-1);
		} else {
                        i=getbits(posbits); j=getbits(lenbits);
                        if (i<0 || j<0) return;
                        i+=r; j+=THRESHOLD;
                        for (k=0; k<=j; k++) {
                                *OutData++=text_buf[r++]=text_buf[(i+k) & (buflen-1)];
                                r&=(buflen-1);
			}
		}
	}
}
